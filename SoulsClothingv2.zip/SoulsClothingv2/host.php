<?php
define('DBHOST', 'localhost');
define('DBNAME', 'project');
define('DBUSER', 'root');
define('DBPASS', '1234');
 ?>
