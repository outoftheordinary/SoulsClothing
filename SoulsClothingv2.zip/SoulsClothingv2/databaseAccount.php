<?php
require_once('host.php');

function db_connect() {
    try {
      $connectionString = 'mysql:host='.DBHOST.';dbname='.DBNAME;
      $pdo = new PDO($connectionString, DBUSER, DBPASS);
      $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
     
     return $pdo;
    }
    catch (PDOException $e)
    {
      die($e->getMessage());
    }
  }

  function handle_form_submission_account() {
    global $pdo;
  
    if($_SERVER["REQUEST_METHOD"] == "POST")
    {   
      if(isset($_POST['name']) && isset($_POST['username']) && isset($_POST['password']) && isset($_POST['verifyPassword'])) {
        $sql = "INSERT INTO account (name, username, password, verifyPassword) VALUES (:name, :username, :password, :verifyPassword)";
       
        $statement = $pdo->prepare($sql);
        $statement->bindValue(':name', $_POST['name']);
        $statement->bindValue(':username', $_POST['username']);
        $statement->bindValue(':password', $_POST['password']);
        $statement->bindValue(':verifyPassword', $_POST['verifyPassword']);
  
        $statement->execute();
      }
    }
  }

  function get_account() {
    global $pdo;
    global $account;

    $sql="SELECT * FROM account ORDER BY ID DESC";
    $result = $pdo->query($sql);
    while ($row=$result->fetch())  {
      $account[]=$row;
    }
      return $account;
  }

  function the_account() {
  global $account;  

  foreach($account as $c) {
      echo "<div class='test'>"; 
      echo "<h2>Congratulations!</h2>";
      echo "<p>Your new account has been made!</p>";
      echo "<p> ID: " . $c["ID"] . "</p>";
      echo "<p'> user: " . $c["username"] . "</p>";
      echo "<p>name: " . $c["name"] . "</p>";
      echo "<p>password: " . $c["password"] . "</p>";
      echo "</div>";
    }
  }

function passwordCheck() {
$password = "SELECT  password FROM account";
$passwordV = "SELECT  verifyPassword FROM account";

    if($password!=$passwordV) {
        echo '<p class="verify">password does not match</p>';
    }
}

function userCheck() {
    global $users;
    $sql="SELECT DISTINCT username FROM account";
    $result = $pdo->query($sql);
    while ($row=$result->fetch())  {
      $users[]=$row;
      for($i=1;$i<$users.length();$i++) {
        if($users[$i]==$users[$i-1]) {
            echo '<p class="error">username already exists. please choose another username</p>';
        }
      }
    }
  }
?>