<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

$account = [];
$users = [];

require_once 'databaseAccount.php';
require_once 'login.php';


$pdo = db_connect();

handle_form_submission_account();

get_account();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="collections.css">
     <script src="myscripts.js"></script>
    <title>Account Created</title>
</head>
<body>
<header>
        <h1>Soul's Collections</h1>
    </header>
<nav>
        <ul>
            <li id="left"> <a href="homepage.php"> <img src="images/soulslogo.png" style="width:50px;height:auto;"
                        alt="Soul's Clothing Logo"> </a> </li>
            <li><a href="index.php">Account Page</a></li>
            <li id="right"> <a href="cart.php"> <img src="images/cart.png" height="50px" alt="Cart icon"> </a>
        </ul>
    </nav>
    <?php
    the_account();
?>
 <div class="return">
      <a href="login.php">
        <button>Login</button>
      </a>
    </div>
</body>
</html>