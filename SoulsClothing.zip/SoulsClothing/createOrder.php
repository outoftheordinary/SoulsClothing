<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

$account = [];

require_once 'databaseOrder.php';

$pdo = db_connect();

handle_form_submission_order();

get_order();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="mystyles.css">
     <script src="myscripts.js"></script>
    <title>Order Created</title>
</head>
<body>
    <?php
the_order();
?>
 <div class="return">
      <a href="cart.php">
        <button>Go to Cart</button>
      </a>
    </div>
</body>
</html>