<?php
require_once('host.php');

function db_connect() {
    try {
      $connectionString = 'mysql:host='.DBHOST.';dbname='.DBNAME;
      $pdo = new PDO($connectionString, DBUSER, DBPASS);
      $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
     
     return $pdo;
    }
    catch (PDOException $e)
    {
      die($e->getMessage());
    }
  }

  function handle_form_submission_order() {
    global $pdo;
  
    if($_SERVER["REQUEST_METHOD"] == "POST")
    {        var_dump($_POST); // Log the form data

      if(isset($_POST['item']) && isset($_POST['size']) && isset($_POST['color'])) {
       $sql= "INSERT INTO orders (username) SELECT username FROM account";
        $sql = "INSERT INTO orders (item, size, color,username) VALUES (:item, :size, :color,:username)";
       
        $statement = $pdo->prepare($sql);
        $statement->bindValue(':item', $_POST['item']);
        $statement->bindValue(':size', $_POST['size']);
        $statement->bindValue(':color', $_POST['color']);
        $statement->bindValue(':username', $_POST['username']);
  
        $statement->execute();

      }
    }
  }

  function get_order() {
    global $pdo;
    global $order;

    $sql="SELECT * FROM account ORDER BY ID DESC";
    $result = $pdo->query($sql);
    while ($row=$result->fetch())  {
      $order[]=$row;
    }
      return $order;
  }

  function the_order() {
  global $order; 
   
    foreach($order as $c) {
      echo "<div class='test'>"; 
      echo "<h2>Congratulations!</h2>";
      echo "<p>Your order has been made!</p>";
      echo "<p> Item#: " . $c["ID"] . "</p>";
      echo "<p> item: " . $c["item"] . "</p>";
      echo "<p>size: " . $c["size"] . "</p>";
      echo "<p>color: " . $c["color"] . "</p>";
      echo "<p>order by: " . $c["username"] . "</p>";
      echo "</div>";
    }
  }
?>