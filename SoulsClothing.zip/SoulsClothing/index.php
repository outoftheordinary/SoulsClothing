<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Account</title>
    <link rel="stylesheet" href="mystyles.css">
    <link rel="icon" type="image/x-icon" href="images/soulslogo.png">
</head>

<body>
    <header>
        <h1>Soul's Collections</h1>
    </header>
    <nav>
        <ul>
            <li id="left"> <a href="homePage.php"> <img src="images/soulslogo.png" style="width:50px;height:auto;"
                        alt="Soul's Clothing Logo"> </a> </li>
            <li><a href="index.php">Account Page</a></li>
            <li id="right"> <a href="cart.php"> <img src="images/cart.png" height="50px" alt="Cart icon"> </a>
        </ul>
    </nav>
    <main>
        <h1 class="account-head">Create An Account</h1>
        <div class="account-form">
       <form action="createAccount.php" method="POST">
       <label for="name">Name:</label>
       <input type="text" name="name" id="name"><br><br>
       <label for="username">Username:</label>
       <input type="text" name="username" id="username">
       <p class="error"><p>
       <label for="password">Password:</label>
       <input type="password" name="password" id="password">
       <p class="verify"><p>
       <label for="verifyPassword">Verify Password:</label>
       <input type="password" name="verifyPassword" id="verifyPassword">
       <button type="submit">Create</button>
       </form>
</div>
    </main>
</body>
</html>