<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

$account = [];

require_once 'databaseAccount.php';

$pdo = db_connect();

handle_form_submission_account();

get_account();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="mystyles.css">
     <script src="myscripts.js"></script>
    <title>Account Created</title>
</head>
<body>
    <?php
    the_account();
?>
 <div class="return">
      <a href="login.php">
        <button>Login</button>
      </a>
    </div>
</body>
</html>